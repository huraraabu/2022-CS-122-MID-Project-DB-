﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Mid_Project
{
    public partial class FrmRubric : Form
    {
        public FrmRubric()
        {
            InitializeComponent();
            dataGridView1.SelectionChanged += dataGridView1_SelectionChanged;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
        }
        public void RefreshDataGridView()
        {
            string Name = comboBox1.Text;
            var connection_1 = Configuration.getInstance().getConnection();

            // Open the connection
            connection_1.Open();

            // Retrieve CloId based on the selected CLO name
            SqlCommand cloCommand = new SqlCommand("SELECT Id FROM Clo WHERE Name = @Name", connection_1);
            cloCommand.Parameters.AddWithValue("@Name", Name);
            int CloId = Convert.ToInt32(cloCommand.ExecuteScalar());

            // Retrieve Rubric data based on CloId
            SqlCommand sample_command = new SqlCommand("SELECT * FROM Rubric WHERE CloId = @CloId", connection_1);
            sample_command.Parameters.AddWithValue("@CloId", CloId);
            SqlDataAdapter adopter_1 = new SqlDataAdapter(sample_command);
            DataTable data_table_1 = new DataTable();
            adopter_1.Fill(data_table_1);

            // Close the connection
            connection_1.Close();

            // Update the DataGridView
            dataGridView1.DataSource = data_table_1;
        }


        private void BtnMark_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem == null)
            {
                MessageBox.Show("Please select a CLO.");
                return;
            }

            using (SqlConnection connection_1 = Configuration.getInstance().getConnection())
            {
                connection_1.Open();

                // Retrieve the CloId based on the selected CLO name
                string selectedCloName = comboBox1.SelectedItem.ToString();
                SqlCommand cmd2 = new SqlCommand("SELECT Id FROM Clo WHERE Name = @Name", connection_1);
                cmd2.Parameters.AddWithValue("@Name", selectedCloName);
                int CloId = Convert.ToInt32(cmd2.ExecuteScalar());

                // Insert the new entry into the Rubric table
                SqlCommand sample_command = new SqlCommand("INSERT INTO Rubric (Id, Details, CloId) VALUES (@Id, @Details, @CloId)", connection_1);
                sample_command.Parameters.AddWithValue("@Id", int.Parse(txtId.Text));
                sample_command.Parameters.AddWithValue("@Details", txtDetails.Text);
                sample_command.Parameters.AddWithValue("@CloId", CloId);
                sample_command.ExecuteNonQuery();

                connection_1.Close();

                MessageBox.Show("Saved Successfully !!!");
                RefreshDataGridView();
            }
        }


        private void FrmRubric_Load(object sender, EventArgs e)
        {
            ShowinComboBox();
            var connection_1 = Configuration.getInstance().getConnection();
            SqlCommand cmd1 = new SqlCommand("SELECT * FROM Rubric", connection_1);
            SqlDataAdapter adopter_1 = new SqlDataAdapter(cmd1);
            DataTable data_table_1 = new DataTable();
            adopter_1.Fill(data_table_1);
            // Update the DataGridView
            dataGridView1.DataSource = data_table_1;
            connection_1.Close();

        }
        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                var connection_1 = Configuration.getInstance().getConnection();
                string Name = comboBox1.Text;
                SqlCommand CloCmd = new SqlCommand("Select Id from Clo WHERE Name = @Name", connection_1);
                CloCmd.Parameters.AddWithValue("@Name", Name);
                connection_1.Open();
                int CloId = Convert.ToInt32(CloCmd.ExecuteScalar());

                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
                int Id = Convert.ToInt32(selectedRow.Cells["Id"].Value);

                //Retrieve Value From TextBoxes
                int rubricId = int.Parse(txtId.Text);
                string details = txtDetails.Text;
                //Updated the Values in the Table
                SqlCommand sample_command = new SqlCommand(@"UPDATE Rubric
                                            SET Id = @Id,
                                                Details = @details
                                                WHERE Id = @Id", connection_1);
                sample_command.Parameters.AddWithValue("@Id", Id);
                sample_command.Parameters.AddWithValue("@Details", details);
                sample_command.Parameters.AddWithValue("@CloId", CloId);

                sample_command.ExecuteNonQuery();
                connection_1.Close();
                MessageBox.Show("Row Updated Successfully !!!");
                RefreshDataGridView();
            }
        }
        private void BtnRemove_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                try
                {
                    DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
                    int RubricId = Convert.ToInt32(selectedRow.Cells["Id"].Value);
                    using (var connection_1 = Configuration.getInstance().getConnection())
                    {
                        connection_1.Open();

                        // Delete related records from the RubricLevel table
                        using (SqlCommand deleteRubricLevelCmd = new SqlCommand("DELETE FROM RubricLevel WHERE RubricId = @RubricId", connection_1))
                        {
                            deleteRubricLevelCmd.Parameters.AddWithValue("@RubricId", RubricId);
                            deleteRubricLevelCmd.ExecuteNonQuery();
                        }

                        // Delete related records from the AssessmentComponent table
                        using (SqlCommand deleteAssessmentComponentCmd = new SqlCommand("DELETE FROM AssessmentComponent WHERE RubricId = @RubricId", connection_1))
                        {
                            deleteAssessmentComponentCmd.Parameters.AddWithValue("@RubricId", RubricId);
                            deleteAssessmentComponentCmd.ExecuteNonQuery();
                        }

                        // Delete the Rubric record
                        using (SqlCommand deleteRubricCmd = new SqlCommand("DELETE FROM Rubric WHERE Id = @Id", connection_1))
                        {
                            deleteRubricCmd.Parameters.AddWithValue("@Id", RubricId);
                            deleteRubricCmd.ExecuteNonQuery();
                        }
                    }

                    MessageBox.Show("Row Deleted Successfully !!!");
                    
                }
                catch (Exception ex)
                {
                    
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
            RefreshDataGridView();
        }


        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
                int Id = Convert.ToInt32(selectedRow.Cells["Id"].Value);

                // Fetch data from the database based on the selected studentId
                var connection_1 = Configuration.getInstance().getConnection();
                SqlCommand sample_command = new SqlCommand("SELECT * FROM Rubric WHERE Id = @Id", connection_1);
                sample_command.Parameters.AddWithValue("@Id", Id);
                connection_1.Open();
                SqlDataReader reader = sample_command.ExecuteReader();

                if (reader.Read())
                {
                    // Retrieve the values from the database
                    int RubricId = Convert.ToInt32(reader["Id"]);
                    string details = reader["Details"].ToString();

                    // Update the text boxes with the retrieved values
                    txtId.Text = RubricId.ToString();
                    txtDetails.Text = details;
                }

                reader.Close();
                connection_1.Close();
            }
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            RefreshDataGridView();
        }

        private void BtnReset_Click(object sender, EventArgs e)
        {
            txtId.Text = "";
            txtDetails.Text = "";
        }
        public void ShowinComboBox()
        {
            var connection_1 = Configuration.getInstance().getConnection();
            SqlCommand sample_command = new SqlCommand(@"SELECT Name from Clo", connection_1);

            SqlDataReader reader = null;

            reader = sample_command.ExecuteReader();

            // Clear existing items in the combo box
            comboBox1.Items.Clear();

            // Populate the combo box with registration numbers
            while (reader.Read())
            {
                string Name = reader["Name"].ToString();
                comboBox1.Items.Add(Name);
            }

            reader.Close();
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            FrmHomeScreen H1 = new FrmHomeScreen();
            this.Hide();
            H1.Show();
        }
    }
}