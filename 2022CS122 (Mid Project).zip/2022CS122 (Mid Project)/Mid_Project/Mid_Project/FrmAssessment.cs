﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Mid_Project
{
    public partial class FrmAssessment : Form
    {
        public FrmAssessment()
        {
            InitializeComponent();
            dataGridView1.SelectionChanged += dataGridView1_SelectionChanged;
        }

        private void FrmAssessment_Load(object sender, EventArgs e)
        {
            Grid_data();
            dataGridView1.ForeColor = Color.Red;
        }

        private void Btn_Add_Click(object sender, EventArgs e)
        {
            var connection_1 = Configuration.getInstance().getConnection();
            SqlCommand sample_command = new SqlCommand("INSERT INTO Assessment (Title, DateCreated, TotalMarks, TotalWeightage) VALUES (@Title, @DateCreated, @TotalMarks, @TotalWeightage)", connection_1);
            sample_command.Parameters.AddWithValue("@Title", txtTitle.Text);
            sample_command.Parameters.AddWithValue("@DateCreated", dateTimePicker1.Value);
            sample_command.Parameters.AddWithValue("@TotalMarks", int.Parse(txtTotalMarks.Text));
            sample_command.Parameters.AddWithValue("@TotalWeightage", int.Parse(txtTotalWeightage.Text));
            connection_1.Open();
            sample_command.ExecuteNonQuery();
            MessageBox.Show("Saved Successfully !!!");
            Grid_data();
        }
        public void Grid_data()
        {
            var connection_1 = Configuration.getInstance().getConnection();
            SqlCommand sample_command = new SqlCommand("SELECT * FROM Assessment", connection_1);
            SqlDataAdapter adopter_1 = new SqlDataAdapter(sample_command);
            DataTable data_table_1 = new DataTable();

            adopter_1.Fill(data_table_1);
            connection_1.Close();

            dataGridView1.DataSource = data_table_1;
        }

        private void Btn_Reset_Click(object sender, EventArgs e)
        {
            txtTitle.Text = "";
            txtTotalMarks.Text = "";
            txtTotalWeightage.Text = "";
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

                // Retrieve the updated values from the textboxes and ComboBox
                string Title = txtTitle.Text;
                DateTime DateCreated = dateTimePicker1.Value;
                int TotalMarks = Convert.ToInt32(txtTotalMarks.Text); // Corrected the conversion
                int TotalWeightage = Convert.ToInt32(txtTotalWeightage.Text); // Corrected the conversion

                // Update the selected row in the database
                var connection_1 = Configuration.getInstance().getConnection();
                SqlCommand sample_command = new SqlCommand(@"UPDATE Assessment 
                                   SET Title = @Title, 
                                       DateCreated = @DateCreated, 
                                       TotalMarks = @TotalMarks, 
                                       TotalWeightage = @TotalWeightage
                                   WHERE Id = @Id", connection_1);

                sample_command.Parameters.AddWithValue("@Title", Title);
                sample_command.Parameters.AddWithValue("@DateCreated", DateCreated);
                sample_command.Parameters.AddWithValue("@TotalMarks", TotalMarks);
                sample_command.Parameters.AddWithValue("@TotalWeightage", TotalWeightage);
                sample_command.Parameters.AddWithValue("@Id", Convert.ToInt32(selectedRow.Cells["Id"].Value));

                connection_1.Open();
                sample_command.ExecuteNonQuery();
                connection_1.Close(); // Close the connection after executing the command

                MessageBox.Show("Row updated successfully.");

                // Refresh DataGridView
                SqlCommand refreshCmd = new SqlCommand("SELECT * FROM Assessment", connection_1);
                SqlDataAdapter adopter_1 = new SqlDataAdapter(refreshCmd);
                DataTable data_table_1 = new DataTable();
                adopter_1.Fill(data_table_1);
                dataGridView1.DataSource = data_table_1;
            }
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
                int Id = Convert.ToInt32(selectedRow.Cells["Id"].Value);

                // Fetch data from the database based on the selected studentId
                var connection_1 = Configuration.getInstance().getConnection();
                SqlCommand sample_command = new SqlCommand("SELECT * FROM Assessment WHERE Id = @Id", connection_1);
                sample_command.Parameters.AddWithValue("@Id", Id);
                connection_1.Open();
                SqlDataReader reader = sample_command.ExecuteReader();

                if (reader.Read())
                {
                    // Retrieve the values from the database
                    string Title = reader["Title"].ToString();
                    DateTime d1 = Convert.ToDateTime(reader["DateCreated"]);
                    int TotalMarks = Convert.ToInt32(reader["TotalMarks"]);
                    int TotalWeightage = Convert.ToInt32(reader["TotalWeightage"]);

                    // Update the text boxes with the retrieved values
                    txtTitle.Text = Title;
                    dateTimePicker1.Value = d1;
                    txtTotalMarks.Text = TotalMarks.ToString();
                    txtTotalWeightage.Text = TotalWeightage.ToString();
                }

                reader.Close();
                connection_1.Close();
            }
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int count = 0;
                try
                {
                    DataGridViewRow selectedRows = dataGridView1.SelectedRows[0];
                    int Id = Convert.ToInt32(selectedRows.Cells["Id"].Value);

                    using (var connection_1 = Configuration.getInstance().getConnection())
                    {
                        connection_1.Open();

                        // Delete related Assessment Components
                        using (SqlCommand deleteAssessmentComponentCmd = new SqlCommand("DELETE FROM AssessmentComponent WHERE AssessmentId = @AssessmentId", connection_1))
                        {
                            deleteAssessmentComponentCmd.Parameters.AddWithValue("@AssessmentId", Id);
                            deleteAssessmentComponentCmd.ExecuteNonQuery();
                        }

                        // Delete the Assessment record
                        using (SqlCommand sample_command = new SqlCommand("DELETE FROM Assessment WHERE Id = @Id", connection_1))
                        {
                            sample_command.Parameters.AddWithValue("@Id", Id);
                            sample_command.ExecuteNonQuery();
                        }
                    }
                    count++;
                    Grid_data();
                    MessageBox.Show("Row Deleted Successfully !!!");
                    
                }
                catch (Exception ex)
                {
                    if (count >= 2)
                    {

                        MessageBox.Show("Error: " + ex.Message);
                    }
                }
            }
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            FrmHomeScreen H1 = new FrmHomeScreen();
            this.Hide();
            H1.Show();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void lblItemName_Click(object sender, EventArgs e)
        {

        }

        private void lblType_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
