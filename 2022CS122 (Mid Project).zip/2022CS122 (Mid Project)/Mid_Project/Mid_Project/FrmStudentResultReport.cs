﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mid_Project
{
    public partial class FrmStudentResultReport : Form
    {
        public FrmStudentResultReport()
        {
            InitializeComponent();
        }

        private void FrmStudentResultReport_Load(object sender, EventArgs e)
        {
            Grid_data();
        }
        public void Grid_data()
        {
            var connection_1 = Configuration.getInstance().getConnection();
            SqlCommand sample_command = new SqlCommand("SELECT * FROM studentResult", connection_1);
            connection_1.Open();
            SqlDataAdapter adopter_1 = new SqlDataAdapter(sample_command);
            DataTable data_table_1 = new DataTable();

            adopter_1.Fill(data_table_1);
            connection_1.Close();

            dataGridView1.DataSource = data_table_1;
        }
        public void QueriesForReport()
        {
            var connection_1 = Configuration.getInstance().getConnection();
            SqlCommand sample_command = new SqlCommand("");
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            FrmStudentResult sample_form = new FrmStudentResult();
            this.Hide();
            sample_form.Show();
        }
    }
}
