﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Mid_Project
{
    public partial class FrmStudentAttendance : Form
    {
        public FrmStudentAttendance()
        {
            InitializeComponent();
        }

        private void FrmStudentAttendance_Load(object sender, EventArgs e)
        {
            var connection_1 = Configuration.getInstance().getConnection();
            SqlCommand sample_command = new SqlCommand(@"
                                    SELECT RegistrationNumber from Student
                                    WHERE Status = '5'", connection_1);

            SqlDataReader reader = null;

            reader = sample_command.ExecuteReader();

            // Clear existing items in the combo box
            cmboxRegistrationNumbers.Items.Clear();

            // Populate the combo box with registration numbers
            while (reader.Read())
            {
                string registrationNumber = reader["RegistrationNumber"].ToString();
                cmboxRegistrationNumbers.Items.Add(registrationNumber);
            }

            reader.Close();
            connection_1.Close();
            var con1 = Configuration.getInstance().getConnection();
            SqlCommand cmd1 = new SqlCommand(@"
                                    SELECT Name from Lookup
                                    WHERE LookupId <= 4", connection_1);

            SqlDataReader reader1 = null;
            con1.Open();
            reader1 = cmd1.ExecuteReader();

            // Populate the combo box with Lookup names
            while (reader1.Read())
            {
                string Names = reader1["Name"].ToString();
                cmboxStatus.Items.Add(Names);
            }

            reader1.Close();
            con1.Close();
            cmboxRegistrationNumbers.DropDownStyle = ComboBoxStyle.DropDownList;
            cmboxStatus.DropDownStyle = ComboBoxStyle.DropDownList;
            showInGrid();
        }

        private void BtnMark_Click(object sender, EventArgs e)
        {
            // Get the selected registration number
            string registrationNumber = cmboxRegistrationNumbers.SelectedItem?.ToString();

            if (string.IsNullOrEmpty(registrationNumber))
            {
                MessageBox.Show("Please select a registration number.");
                return;
            }

            // Get the selected status
            string status = cmboxStatus.SelectedItem?.ToString();

            if (string.IsNullOrEmpty(status))
            {
                MessageBox.Show("Please select an attendance status.");
                return;
            }

            // Convert status to its corresponding value
            int attendanceStatus = 0;
            switch (status)
            {
                case "Present":
                    attendanceStatus = 1;
                    break;
                case "Absent":
                    attendanceStatus = 2;
                    break;
                case "Leave":
                    attendanceStatus = 3;
                    break;
                case "Late":
                    attendanceStatus = 4;
                    break;
                default:
                    MessageBox.Show("Invalid attendance status.");
                    return;
            }

            using (SqlConnection connection_1 = Configuration.getInstance().getConnection())
            {
                connection_1.Open();

                // Insert data into ClassAttendance table
                SqlCommand cmd1 = new SqlCommand("INSERT INTO ClassAttendance (AttendanceDate) VALUES (@AttendanceDate); SELECT SCOPE_IDENTITY();", connection_1);
                cmd1.Parameters.AddWithValue("@AttendanceDate", DateTime.Now);
                int classAttendanceId = Convert.ToInt32(cmd1.ExecuteScalar());

                // Retrieve student ID
                SqlCommand cmd2 = new SqlCommand("SELECT Id FROM Student WHERE RegistrationNumber = @RegistrationNumber", connection_1);
                cmd2.Parameters.AddWithValue("@RegistrationNumber", registrationNumber);
                int studentId = Convert.ToInt32(cmd2.ExecuteScalar());

                // Insert data into StudentAttendance table
                SqlCommand cmd3 = new SqlCommand("INSERT INTO StudentAttendance (AttendanceId, StudentId, AttendanceStatus) VALUES (@ClassAttendanceId, @StudentId, @AttendanceStatus)", connection_1);
                cmd3.Parameters.AddWithValue("@AttendanceId", classAttendanceId);
                cmd3.Parameters.AddWithValue("@StudentId", studentId);
                cmd3.Parameters.AddWithValue("@AttendanceStatus", attendanceStatus);
                int rowsAffected = cmd3.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    MessageBox.Show("Attendance marked successfully.");
                }
                else
                {
                    MessageBox.Show("Failed to mark attendance.");
                }
            }
            showInGrid();
        }

        public void showInGrid()
        {
            var connection_1 = Configuration.getInstance().getConnection();
            SqlCommand sample_command = new SqlCommand("SELECT * FROM StudentAttendance", connection_1);
            SqlDataAdapter adopter_1 = new SqlDataAdapter(sample_command);
            DataTable data_table_1 = new DataTable();

            adopter_1.Fill(data_table_1);
            connection_1.Close();

            dataGridView1.DataSource = data_table_1;
        }
        public string GetStudentId()
        {
            return " SELECT Id FROM Student where RegistrationNumber=@RegistrationNumber";
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            
        }

        private void BtnBack_Click_1(object sender, EventArgs e)
        {
            FrmHomeScreen H1 = new FrmHomeScreen();
            this.Hide();
            H1.Show();
        }
    }
}