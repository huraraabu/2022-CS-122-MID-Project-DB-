﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace Mid_Project
{
    public partial class FrmStudentResult : Form
    {
        public FrmStudentResult()
        {
            InitializeComponent();
            //dataGridView1.SelectionChanged += dataGridView1_SelectionChanged;
        }

        private void FrmStudentResult_Load(object sender, EventArgs e)
        {
            student_combo_bx();
            as_comp_combo_bx();
            marks_combo_bx();
            rubric_combo_bx();
            assessment_combo_bx();
        }

        private void BtnMark_Click(object sender, EventArgs e)
        {
            if (cmBoxStudent.Text == "" && cmBoxComponent.Text == "")
            {
                MessageBox.Show("Please Select Student and Assessment Component !!!");
                return;
            }
            var connection_1 = Configuration.getInstance().getConnection();
            //Retrieve Id From Student 
            string RegistrationNumber = cmBoxStudent.Text;
            SqlCommand studentCmd = new SqlCommand("Select Id from Student WHERE RegistrationNumber = @RegistrationNumber", connection_1);
            studentCmd.Parameters.AddWithValue("@RegistrationNumber", RegistrationNumber);
            connection_1.Open();

            //Retrieve Id From Assessment Component
            int StudentId = Convert.ToInt32(studentCmd.ExecuteScalar());
            string Name = cmBoxComponent.Text;
            SqlCommand AssessmentCmd = new SqlCommand("Select Id from AssessmentComponent WHERE Name = @Name", connection_1);
            AssessmentCmd.Parameters.AddWithValue("@Name", Name);
            int AssessmentComponentId = Convert.ToInt32(AssessmentCmd.ExecuteScalar());

            //Retrieve Id From Rubric
            SqlCommand RubricCmd = new SqlCommand("Select Id From RubricLevel WHERE MeasurementLevel = @MeasurementLevel", connection_1);
            RubricCmd.Parameters.AddWithValue("@MeasurementLevel", cmBoxObtainedMarks.Text);
            int RubricId = Convert.ToInt32(RubricCmd.ExecuteScalar());


            //Insert Data into Database
            SqlCommand sample_command = new SqlCommand("INSERT into StudentResult (StudentId, AssessmentComponentId,RubricMeasurementId, EvaluationDate) VALUES(@StudentId, @AssessmentComponentId, @RubricMeasurementId, @EvaluationDate)", connection_1);
            sample_command.Parameters.AddWithValue("@StudentId", StudentId);
            sample_command.Parameters.AddWithValue("@RubricMeasurementId", RubricId);
            sample_command.Parameters.AddWithValue("@AssessmentComponentId", AssessmentComponentId);
            sample_command.Parameters.AddWithValue("@EvaluationDate", Convert.ToDateTime(dateTimePicker1.Value));
            sample_command.ExecuteNonQuery();
            connection_1.Close();
            MessageBox.Show("Added Successfully !!!");
        }

        //Show Student in Combo Box
        public void student_combo_bx()
        {
            var connection_1 = Configuration.getInstance().getConnection();
            SqlCommand sample_command = new SqlCommand(@"
                                    SELECT RegistrationNumber from Student
                                    WHERE Status = '5'", connection_1);

            SqlDataReader reader = null;
            connection_1.Open();
            reader = sample_command.ExecuteReader();

            // Clear existing items in the combo box
            cmBoxStudent.Items.Clear();

            // Populate the combo box with registration numbers
            while (reader.Read())
            {
                string registrationNumber = reader["RegistrationNumber"].ToString();
                cmBoxStudent.Items.Add(registrationNumber);
            }

            reader.Close();
            connection_1.Close();
        }

        //Show Assessments in Combo Box
        public void assessment_combo_bx()
        {
            var connection_1 = Configuration.getInstance().getConnection();
            SqlCommand sample_command = new SqlCommand(@"SELECT Title from Assessment", connection_1);

            SqlDataReader reader = null;
            connection_1.Open();
            reader = sample_command.ExecuteReader();

            // Clear existing items in the combo box
            cmBoxAssessment.Items.Clear();

            // Populate the combo box with registration numbers
            while (reader.Read())
            {
                string Name = reader["Title"].ToString();
                cmBoxAssessment.Items.Add(Name);
            }

            reader.Close();
            connection_1.Close();
        }

        //Show Assessment Component in Combo Box
        public void as_comp_combo_bx()
        {
            var connection_1 = Configuration.getInstance().getConnection();
            SqlCommand sample_command = new SqlCommand(@"SELECT Name from AssessmentComponent", connection_1);

            SqlDataReader reader = null;
            connection_1.Open();
            reader = sample_command.ExecuteReader();

            // Clear existing items in the combo box
            cmBoxComponent.Items.Clear();

            // Populate the combo box with registration numbers
            while (reader.Read())
            {
                string Name = reader["Name"].ToString();
                cmBoxComponent.Items.Add(Name);
            }

            reader.Close();
            connection_1.Close();
        }

        //private void BtnRemove_Click(object sender, EventArgs e)
        //{
        //    if (dataGridView1.SelectedRows.Count > 0)
        //    {
        //        DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
        //        int StudentId = Convert.ToInt32(selectedRow.Cells["StudentId"].Value);

        //        // Remove the selected row from the database
        //        var connection_1 = Configuration.getInstance().getConnection();
        //        connection_1.Open();
        //        SqlCommand sample_command = new SqlCommand("DELETE FROM StudentResult WHERE StudentId = @StudentId", connection_1);
        //        sample_command.Parameters.AddWithValue("@StudentId", StudentId);

        //        // Execute the command
        //        sample_command.ExecuteNonQuery();
        //        connection_1.Close();
        //        MessageBox.Show("Row deleted successfully.");
        //        Grid_data();
        //    }
        //}
        //private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        //{
        //    if (dataGridView1.SelectedRows.Count > 0)
        //    {
        //        DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
        //        int Id = Convert.ToInt32(selectedRow.Cells["StudentId"].Value);

        //        // Fetch data from the database based on the selected studentId
        //        var connection_1 = Configuration.getInstance().getConnection();
        //        SqlCommand sample_command = new SqlCommand("SELECT * FROM StudentResult WHERE StudentId = @Id", connection_1);
        //        sample_command.Parameters.AddWithValue("@Id", Id);
        //        connection_1.Open();
        //        SqlDataReader reader = sample_command.ExecuteReader();

        //        if (reader.Read())
        //        {
        //            // Retrieve the values from the database
        //            int RubricId = Convert.ToInt32(reader["StudentId"]);
        //            DateTime EvaluationDate = Convert.ToDateTime(reader["EvaluationDate"]);

        //            // Update the text boxes with the retrieved values
        //            dateTimePicker1.Value = EvaluationDate;
        //        }

        //        reader.Close();
        //        connection_1.Close();
        //    }
        //}

        //private void BtnUpdate_Click(object sender, EventArgs e)
        //{
        //    if (dataGridView1.SelectedRows.Count > 0)
        //    {
        //        var connection_1 = Configuration.getInstance().getConnection();
        //        connection_1.Open();
        //        //string Name = comboBox2.Text;
        //        //SqlCommand CloCmd = new SqlCommand("Select Id from AssessmentComponent WHERE Name = @Name", connection_1);
        //        //CloCmd.Parameters.AddWithValue("@Name", Name);
        //        //connection_1.Open();
        //        //int AssessmentId = Convert.ToInt32(CloCmd.ExecuteScalar());

        //        DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
        //        int StudentId = Convert.ToInt32(selectedRow.Cells["StudentId"].Value);

        //        //Retrieve Value From TextBoxes
        //        DateTime EvaluationDate = dateTimePicker1.Value;
        //        //Updated the Values in the Table
        //        SqlCommand sample_command = new SqlCommand(@"UPDATE StudentResult
        //                                    SET EvaluationDate = @EvaluationDate
        //                                        WHERE StudentId = @StudentId", connection_1);
        //        sample_command.Parameters.AddWithValue("@EvaluationDate", EvaluationDate);
        //        sample_command.Parameters.AddWithValue("@StudentId", StudentId);

        //        sample_command.ExecuteNonQuery();
        //        connection_1.Close();
        //        MessageBox.Show("Row Updated Successfully !!!");
        //        Grid_data();
        //    }
        //}


        //Show Obtained Marks in Combo Box
        public void marks_combo_bx()
        {
            var connection_1 = Configuration.getInstance().getConnection();
            SqlCommand sample_command = new SqlCommand(@"SELECT MeasurementLevel from rubricLevel", connection_1);

            SqlDataReader reader = null;
            connection_1.Open();
            reader = sample_command.ExecuteReader();

            // Clear existing items in the combo box
            cmBoxObtainedMarks.Items.Clear();

            // Populate the combo box with registration numbers
            while (reader.Read())
            {
                string Name = reader["MeasurementLevel"].ToString();
                cmBoxObtainedMarks.Items.Add(Name);
            }

            reader.Close();
            connection_1.Close();
        }

        //Show Rubrics in Combo Box 
        public void rubric_combo_bx()
        {
            var connection_1 = Configuration.getInstance().getConnection();
            SqlCommand sample_command = new SqlCommand(@"SELECT Details from Rubric", connection_1);

            SqlDataReader reader = null;
            connection_1.Open();
            reader = sample_command.ExecuteReader();

            // Clear existing items in the combo box
            cmBoxRubric.Items.Clear();

            // Populate the combo box with registration numbers
            while (reader.Read())
            {
                string Name = reader["Details"].ToString();
                cmBoxRubric.Items.Add(Name);
            }

            reader.Close();
            connection_1.Close();
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            FrmHomeScreen H1 = new FrmHomeScreen();
            this.Hide();
            H1.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FrmStudentResultReport H1 = new FrmStudentResultReport();
            this.Hide();
            H1.Show();
        }
    }
}