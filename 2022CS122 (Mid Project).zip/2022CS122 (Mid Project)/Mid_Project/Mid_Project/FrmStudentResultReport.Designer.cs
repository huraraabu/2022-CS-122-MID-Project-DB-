﻿namespace Mid_Project
{
    partial class FrmStudentResultReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.BtnRrport = new System.Windows.Forms.Button();
            this.BtnBack = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 64);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1173, 338);
            this.dataGridView1.TabIndex = 0;
            // 
            // BtnRrport
            // 
            this.BtnRrport.AutoEllipsis = true;
            this.BtnRrport.BackColor = System.Drawing.Color.Teal;
            this.BtnRrport.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnRrport.FlatAppearance.BorderSize = 0;
            this.BtnRrport.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSlateGray;
            this.BtnRrport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnRrport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnRrport.ForeColor = System.Drawing.Color.White;
            this.BtnRrport.Location = new System.Drawing.Point(754, 420);
            this.BtnRrport.Name = "BtnRrport";
            this.BtnRrport.Size = new System.Drawing.Size(144, 34);
            this.BtnRrport.TabIndex = 90;
            this.BtnRrport.Text = "Generate Report";
            this.BtnRrport.UseVisualStyleBackColor = false;
            // 
            // BtnBack
            // 
            this.BtnBack.AutoEllipsis = true;
            this.BtnBack.BackColor = System.Drawing.Color.Teal;
            this.BtnBack.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnBack.FlatAppearance.BorderSize = 0;
            this.BtnBack.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSlateGray;
            this.BtnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnBack.ForeColor = System.Drawing.Color.White;
            this.BtnBack.Location = new System.Drawing.Point(293, 420);
            this.BtnBack.Name = "BtnBack";
            this.BtnBack.Size = new System.Drawing.Size(116, 34);
            this.BtnBack.TabIndex = 89;
            this.BtnBack.Text = "Back";
            this.BtnBack.UseVisualStyleBackColor = false;
            this.BtnBack.Click += new System.EventHandler(this.BtnBack_Click);
            // 
            // FrmStudentResultReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1196, 466);
            this.Controls.Add(this.BtnRrport);
            this.Controls.Add(this.BtnBack);
            this.Controls.Add(this.dataGridView1);
            this.Name = "FrmStudentResultReport";
            this.Text = "FrmStudentResultReport";
            this.Load += new System.EventHandler(this.FrmStudentResultReport_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button BtnRrport;
        private System.Windows.Forms.Button BtnBack;
    }
}