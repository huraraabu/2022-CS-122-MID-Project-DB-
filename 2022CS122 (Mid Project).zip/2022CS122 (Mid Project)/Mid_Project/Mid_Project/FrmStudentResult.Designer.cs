﻿namespace Mid_Project
{
    partial class FrmStudentResult
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnBack = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.cmBoxStudent = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.BtnMark = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.cmBoxComponent = new System.Windows.Forms.ComboBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.cmBoxObtainedMarks = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cmBoxAssessment = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.cmBoxRubric = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // BtnBack
            // 
            this.BtnBack.AutoEllipsis = true;
            this.BtnBack.BackColor = System.Drawing.Color.Teal;
            this.BtnBack.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnBack.FlatAppearance.BorderSize = 0;
            this.BtnBack.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSlateGray;
            this.BtnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnBack.ForeColor = System.Drawing.Color.White;
            this.BtnBack.Location = new System.Drawing.Point(101, 404);
            this.BtnBack.Name = "BtnBack";
            this.BtnBack.Size = new System.Drawing.Size(119, 34);
            this.BtnBack.TabIndex = 87;
            this.BtnBack.Text = "Back";
            this.BtnBack.UseVisualStyleBackColor = false;
            this.BtnBack.Click += new System.EventHandler(this.BtnBack_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(221, 112);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(107, 16);
            this.label3.TabIndex = 84;
            this.label3.Text = "Select Student";
            // 
            // cmBoxStudent
            // 
            this.cmBoxStudent.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmBoxStudent.FormattingEnabled = true;
            this.cmBoxStudent.Location = new System.Drawing.Point(375, 111);
            this.cmBoxStudent.Name = "cmBoxStudent";
            this.cmBoxStudent.Size = new System.Drawing.Size(203, 21);
            this.cmBoxStudent.TabIndex = 83;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(108, 297);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(220, 16);
            this.label2.TabIndex = 80;
            this.label2.Text = "Select Student Obtained Marks";
            // 
            // BtnMark
            // 
            this.BtnMark.AutoEllipsis = true;
            this.BtnMark.BackColor = System.Drawing.Color.Teal;
            this.BtnMark.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnMark.FlatAppearance.BorderSize = 0;
            this.BtnMark.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSlateGray;
            this.BtnMark.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnMark.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnMark.ForeColor = System.Drawing.Color.White;
            this.BtnMark.Location = new System.Drawing.Point(325, 404);
            this.BtnMark.Name = "BtnMark";
            this.BtnMark.Size = new System.Drawing.Size(106, 34);
            this.BtnMark.TabIndex = 79;
            this.BtnMark.Text = "Add";
            this.BtnMark.UseVisualStyleBackColor = false;
            this.BtnMark.Click += new System.EventHandler(this.BtnMark_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Stencil", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(218, 37);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(370, 32);
            this.label4.TabIndex = 77;
            this.label4.Text = "MANAGE STUDENT RESULT";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(211, 342);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(117, 16);
            this.label1.TabIndex = 75;
            this.label1.Text = "Evaluation Date";
            // 
            // button1
            // 
            this.button1.AutoEllipsis = true;
            this.button1.BackColor = System.Drawing.Color.Teal;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSlateGray;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(513, 404);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(160, 34);
            this.button1.TabIndex = 88;
            this.button1.Text = "Show Result Report";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(107, 253);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(221, 16);
            this.label5.TabIndex = 90;
            this.label5.Text = "Select Assessment Component";
            // 
            // cmBoxComponent
            // 
            this.cmBoxComponent.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmBoxComponent.FormattingEnabled = true;
            this.cmBoxComponent.Location = new System.Drawing.Point(375, 248);
            this.cmBoxComponent.Name = "cmBoxComponent";
            this.cmBoxComponent.Size = new System.Drawing.Size(203, 21);
            this.cmBoxComponent.TabIndex = 89;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CalendarMonthBackground = System.Drawing.SystemColors.ScrollBar;
            this.dateTimePicker1.Location = new System.Drawing.Point(375, 338);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(203, 20);
            this.dateTimePicker1.TabIndex = 91;
            // 
            // cmBoxObtainedMarks
            // 
            this.cmBoxObtainedMarks.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmBoxObtainedMarks.FormattingEnabled = true;
            this.cmBoxObtainedMarks.Location = new System.Drawing.Point(375, 292);
            this.cmBoxObtainedMarks.Name = "cmBoxObtainedMarks";
            this.cmBoxObtainedMarks.Size = new System.Drawing.Size(203, 21);
            this.cmBoxObtainedMarks.TabIndex = 92;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(107, 159);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(225, 16);
            this.label6.TabIndex = 94;
            this.label6.Text = "Select Assessment For Marking";
            // 
            // cmBoxAssessment
            // 
            this.cmBoxAssessment.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmBoxAssessment.FormattingEnabled = true;
            this.cmBoxAssessment.Location = new System.Drawing.Point(375, 154);
            this.cmBoxAssessment.Name = "cmBoxAssessment";
            this.cmBoxAssessment.Size = new System.Drawing.Size(203, 21);
            this.cmBoxAssessment.TabIndex = 93;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(228, 208);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(100, 16);
            this.label7.TabIndex = 96;
            this.label7.Text = "Select Rubric";
            // 
            // cmBoxRubric
            // 
            this.cmBoxRubric.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmBoxRubric.FormattingEnabled = true;
            this.cmBoxRubric.Location = new System.Drawing.Point(375, 203);
            this.cmBoxRubric.Name = "cmBoxRubric";
            this.cmBoxRubric.Size = new System.Drawing.Size(203, 21);
            this.cmBoxRubric.TabIndex = 95;
            // 
            // FrmStudentResult
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(756, 450);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.cmBoxRubric);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.cmBoxAssessment);
            this.Controls.Add(this.cmBoxObtainedMarks);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.cmBoxComponent);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.BtnBack);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cmBoxStudent);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.BtnMark);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label1);
            this.Name = "FrmStudentResult";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmStudentResult";
            this.Load += new System.EventHandler(this.FrmStudentResult_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnBack;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmBoxStudent;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button BtnMark;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmBoxComponent;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.ComboBox cmBoxObtainedMarks;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cmBoxAssessment;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cmBoxRubric;
    }
}