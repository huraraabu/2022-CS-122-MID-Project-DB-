﻿namespace Mid_Project
{
    partial class FrmHomeScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnStudent = new System.Windows.Forms.Button();
            this.BtnRubric = new System.Windows.Forms.Button();
            this.BtnComponents = new System.Windows.Forms.Button();
            this.BtnClo = new System.Windows.Forms.Button();
            this.BtnRubricLevel = new System.Windows.Forms.Button();
            this.BtnAssessments = new System.Windows.Forms.Button();
            this.BtnAttendance = new System.Windows.Forms.Button();
            this.BtnResult = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.BtnSetting = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtnStudent
            // 
            this.BtnStudent.AutoEllipsis = true;
            this.BtnStudent.BackColor = System.Drawing.Color.Gainsboro;
            this.BtnStudent.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnStudent.FlatAppearance.BorderSize = 0;
            this.BtnStudent.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSlateGray;
            this.BtnStudent.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnStudent.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnStudent.ForeColor = System.Drawing.Color.Black;
            this.BtnStudent.Location = new System.Drawing.Point(45, 100);
            this.BtnStudent.Name = "BtnStudent";
            this.BtnStudent.Size = new System.Drawing.Size(226, 97);
            this.BtnStudent.TabIndex = 89;
            this.BtnStudent.Text = "MANAGE SUDENTS";
            this.BtnStudent.UseVisualStyleBackColor = false;
            this.BtnStudent.Click += new System.EventHandler(this.BtnStudent_Click);
            // 
            // BtnRubric
            // 
            this.BtnRubric.AutoEllipsis = true;
            this.BtnRubric.BackColor = System.Drawing.Color.Gainsboro;
            this.BtnRubric.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnRubric.FlatAppearance.BorderSize = 0;
            this.BtnRubric.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSlateGray;
            this.BtnRubric.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnRubric.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnRubric.ForeColor = System.Drawing.Color.Black;
            this.BtnRubric.Location = new System.Drawing.Point(494, 203);
            this.BtnRubric.Name = "BtnRubric";
            this.BtnRubric.Size = new System.Drawing.Size(223, 101);
            this.BtnRubric.TabIndex = 91;
            this.BtnRubric.Text = "MANAGE RUBRICS";
            this.BtnRubric.UseVisualStyleBackColor = false;
            this.BtnRubric.Click += new System.EventHandler(this.BtnRubric_Click);
            // 
            // BtnComponents
            // 
            this.BtnComponents.AutoEllipsis = true;
            this.BtnComponents.BackColor = System.Drawing.Color.Gainsboro;
            this.BtnComponents.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnComponents.FlatAppearance.BorderSize = 0;
            this.BtnComponents.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSlateGray;
            this.BtnComponents.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnComponents.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnComponents.ForeColor = System.Drawing.Color.Black;
            this.BtnComponents.Location = new System.Drawing.Point(277, 203);
            this.BtnComponents.Name = "BtnComponents";
            this.BtnComponents.Size = new System.Drawing.Size(211, 101);
            this.BtnComponents.TabIndex = 92;
            this.BtnComponents.Text = "MANAGE ASSESSMENT COMPONENTS";
            this.BtnComponents.UseVisualStyleBackColor = false;
            this.BtnComponents.Click += new System.EventHandler(this.BtnComponents_Click);
            // 
            // BtnClo
            // 
            this.BtnClo.AutoEllipsis = true;
            this.BtnClo.BackColor = System.Drawing.Color.Gainsboro;
            this.BtnClo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnClo.FlatAppearance.BorderSize = 0;
            this.BtnClo.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSlateGray;
            this.BtnClo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnClo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnClo.ForeColor = System.Drawing.Color.Black;
            this.BtnClo.Location = new System.Drawing.Point(45, 203);
            this.BtnClo.Name = "BtnClo";
            this.BtnClo.Size = new System.Drawing.Size(226, 101);
            this.BtnClo.TabIndex = 93;
            this.BtnClo.Text = "MANAGE CLOs";
            this.BtnClo.UseVisualStyleBackColor = false;
            this.BtnClo.Click += new System.EventHandler(this.BtnClo_Click);
            // 
            // BtnRubricLevel
            // 
            this.BtnRubricLevel.AutoEllipsis = true;
            this.BtnRubricLevel.BackColor = System.Drawing.Color.Gainsboro;
            this.BtnRubricLevel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnRubricLevel.FlatAppearance.BorderSize = 0;
            this.BtnRubricLevel.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSlateGray;
            this.BtnRubricLevel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnRubricLevel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnRubricLevel.ForeColor = System.Drawing.Color.Black;
            this.BtnRubricLevel.Location = new System.Drawing.Point(47, 310);
            this.BtnRubricLevel.Name = "BtnRubricLevel";
            this.BtnRubricLevel.Size = new System.Drawing.Size(224, 99);
            this.BtnRubricLevel.TabIndex = 94;
            this.BtnRubricLevel.Text = "MANAGE RUBRIC LEVELS";
            this.BtnRubricLevel.UseVisualStyleBackColor = false;
            this.BtnRubricLevel.Click += new System.EventHandler(this.BtnRubricLevel_Click);
            // 
            // BtnAssessments
            // 
            this.BtnAssessments.AutoEllipsis = true;
            this.BtnAssessments.BackColor = System.Drawing.Color.Gainsboro;
            this.BtnAssessments.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnAssessments.FlatAppearance.BorderSize = 0;
            this.BtnAssessments.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSlateGray;
            this.BtnAssessments.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnAssessments.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnAssessments.ForeColor = System.Drawing.Color.Black;
            this.BtnAssessments.Location = new System.Drawing.Point(494, 100);
            this.BtnAssessments.Name = "BtnAssessments";
            this.BtnAssessments.Size = new System.Drawing.Size(223, 97);
            this.BtnAssessments.TabIndex = 95;
            this.BtnAssessments.Text = "MANAGE ASSESSMENTS";
            this.BtnAssessments.UseVisualStyleBackColor = false;
            this.BtnAssessments.Click += new System.EventHandler(this.BtnAssessments_Click);
            // 
            // BtnAttendance
            // 
            this.BtnAttendance.AutoEllipsis = true;
            this.BtnAttendance.BackColor = System.Drawing.Color.Gainsboro;
            this.BtnAttendance.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnAttendance.FlatAppearance.BorderSize = 0;
            this.BtnAttendance.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSlateGray;
            this.BtnAttendance.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnAttendance.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnAttendance.ForeColor = System.Drawing.Color.Black;
            this.BtnAttendance.Location = new System.Drawing.Point(277, 100);
            this.BtnAttendance.Name = "BtnAttendance";
            this.BtnAttendance.Size = new System.Drawing.Size(211, 97);
            this.BtnAttendance.TabIndex = 96;
            this.BtnAttendance.Text = "MANAGE ATTENDANCES";
            this.BtnAttendance.UseVisualStyleBackColor = false;
            this.BtnAttendance.Click += new System.EventHandler(this.BtnAttendance_Click);
            // 
            // BtnResult
            // 
            this.BtnResult.AutoEllipsis = true;
            this.BtnResult.BackColor = System.Drawing.Color.Gainsboro;
            this.BtnResult.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnResult.FlatAppearance.BorderSize = 0;
            this.BtnResult.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSlateGray;
            this.BtnResult.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnResult.ForeColor = System.Drawing.Color.Black;
            this.BtnResult.Location = new System.Drawing.Point(277, 310);
            this.BtnResult.Name = "BtnResult";
            this.BtnResult.Size = new System.Drawing.Size(211, 99);
            this.BtnResult.TabIndex = 97;
            this.BtnResult.Text = "MANAGE STUDENT RESULT";
            this.BtnResult.UseVisualStyleBackColor = false;
            this.BtnResult.Click += new System.EventHandler(this.BtnResult_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Stencil", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(251, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(282, 29);
            this.label1.TabIndex = 90;
            this.label1.Text = "UET(CS DEPARTMENT)";
            // 
            // BtnSetting
            // 
            this.BtnSetting.AutoEllipsis = true;
            this.BtnSetting.BackColor = System.Drawing.Color.Gainsboro;
            this.BtnSetting.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnSetting.FlatAppearance.BorderSize = 0;
            this.BtnSetting.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSlateGray;
            this.BtnSetting.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnSetting.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSetting.ForeColor = System.Drawing.Color.Black;
            this.BtnSetting.Location = new System.Drawing.Point(494, 310);
            this.BtnSetting.Name = "BtnSetting";
            this.BtnSetting.Size = new System.Drawing.Size(223, 99);
            this.BtnSetting.TabIndex = 98;
            this.BtnSetting.Text = "UPDATES";
            this.BtnSetting.UseVisualStyleBackColor = false;
            this.BtnSetting.Click += new System.EventHandler(this.BtnSetting_Click);
            // 
            // FrmHomeScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.ClientSize = new System.Drawing.Size(740, 430);
            this.Controls.Add(this.BtnSetting);
            this.Controls.Add(this.BtnResult);
            this.Controls.Add(this.BtnAttendance);
            this.Controls.Add(this.BtnAssessments);
            this.Controls.Add(this.BtnRubricLevel);
            this.Controls.Add(this.BtnClo);
            this.Controls.Add(this.BtnComponents);
            this.Controls.Add(this.BtnRubric);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BtnStudent);
            this.Name = "FrmHomeScreen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmHomeScreen";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnStudent;
        private System.Windows.Forms.Button BtnRubric;
        private System.Windows.Forms.Button BtnComponents;
        private System.Windows.Forms.Button BtnClo;
        private System.Windows.Forms.Button BtnRubricLevel;
        private System.Windows.Forms.Button BtnAssessments;
        private System.Windows.Forms.Button BtnAttendance;
        private System.Windows.Forms.Button BtnResult;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button BtnSetting;
    }
}