﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mid_Project
{
    public partial class FrmCLO : Form
    {
        public FrmCLO()
        {
            InitializeComponent();
            dataGridView2.SelectionChanged += dataGridView1_SelectionChanged;
        }

        private void FrmCLO_Load(object sender, EventArgs e)
        {
            Grid_data();
        }

        private void Btn_Add_Click(object sender, EventArgs e)
        {
            var connection_1 = Configuration.getInstance().getConnection();
            SqlCommand sample_command = new SqlCommand("INSERT into CLO (Name, DateCreated, DateUpdated) VALUES (@Name, @DateCreated, @DateUpdated)",connection_1);
            sample_command.Parameters.AddWithValue("@Name", txtName.Text);
            sample_command.Parameters.AddWithValue("@DateCreated", dtPickerDateCreated.Value);
            sample_command.Parameters.AddWithValue("@DateUpdated", dtPickerDateUpdated.Value);

            connection_1.Open();
            sample_command.ExecuteNonQuery();
            connection_1.Close();
            MessageBox.Show("Saved Successfully !!!");
            Grid_data();
        }
        private void Grid_data()
        {
            var connection_1 = Configuration.getInstance().getConnection();
            SqlCommand sample_command = new SqlCommand("SELECT * FROM CLO", connection_1);
            SqlDataAdapter adopter_1 = new SqlDataAdapter(sample_command);
            DataTable data_table_1 = new DataTable();

            adopter_1.Fill(data_table_1);
            connection_1.Close();

            dataGridView2.DataSource = data_table_1;
        }

        private void Btn_Reset_Click(object sender, EventArgs e)
        {
            txtName.Text = "";
            dtPickerDateCreated.Value = DateTime.Now;
            dtPickerDateUpdated.Value = DateTime.Now;
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            if(dataGridView2.SelectedRows.Count>0)
            {
                DataGridViewRow selectedRow = dataGridView2.SelectedRows[0];
                int Id = Convert.ToInt32(selectedRow.Cells["Id"].Value);

                //Retrieve Value From TextBoxes
                string Name = txtName.Text;
                DateTime DateCreated = dtPickerDateCreated.Value;
                DateTime DateUpdated = dtPickerDateUpdated.Value;
                //Updated the Values in the Table
                var connection_1 = Configuration.getInstance().getConnection();
                SqlCommand sample_command = new SqlCommand(@"UPDATE CLO
                                            SET Name = @Name,
                                                DateCreated = @DateCreated,
                                                DateUpdated = @DateUpdated
                                                WHERE Id = @Id", connection_1);
                sample_command.Parameters.AddWithValue("@Id", Id);
                sample_command.Parameters.AddWithValue("@Name",Name);
                sample_command.Parameters.AddWithValue("@DateCreated", DateCreated);
                sample_command.Parameters.AddWithValue("@DateUpdated", DateUpdated);

                connection_1.Open();
                sample_command.ExecuteNonQuery();
                connection_1.Close();
                MessageBox.Show("Row Updated Successfully !!!");
                Grid_data();
            }
        }
        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView2.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView2.SelectedRows[0];
                int Id = Convert.ToInt32(selectedRow.Cells["Id"].Value);

                // Fetch data from the database based on the selected studentId
                var connection_1 = Configuration.getInstance().getConnection();
                SqlCommand sample_command = new SqlCommand("SELECT * FROM CLO WHERE Id = @Id", connection_1);
                sample_command.Parameters.AddWithValue("@Id", Id);
                connection_1.Open();
                SqlDataReader reader = sample_command.ExecuteReader();

                if (reader.Read())
                {
                    // Retrieve the values from the database
                    string Name = reader["Name"].ToString();
                    DateTime d1 = Convert.ToDateTime(reader["DateCreated"]);
                    DateTime d2 = Convert.ToDateTime(reader["DateUpdated"]);

                    // Update the text boxes with the retrieved values
                    txtName.Text = Name;
                    dtPickerDateCreated.Value = d1;
                    dtPickerDateUpdated.Value = d2;
                }

                reader.Close();
                connection_1.Close();
            }
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView2.SelectedRows.Count > 0)
            {
                try
                {
                    DataGridViewRow selectedRow = dataGridView2.SelectedRows[0];
                    int CloId = Convert.ToInt32(selectedRow.Cells["Id"].Value);

                    using (var connection_1 = Configuration.getInstance().getConnection())
                    {
                        connection_1.Open();

                        // Delete related records from the RubricLevel table
                        using (SqlCommand deleteRubricLevelCmd = new SqlCommand("DELETE FROM RubricLevel WHERE RubricId IN (SELECT Id FROM Rubric WHERE CloId = @CloId)", connection_1))
                        {
                            deleteRubricLevelCmd.Parameters.AddWithValue("@CloId", CloId);
                            deleteRubricLevelCmd.ExecuteNonQuery();
                        }

                        // Delete related records from the AssessmentComponent table
                        using (SqlCommand deleteAssessmentComponentCmd = new SqlCommand("DELETE FROM AssessmentComponent WHERE RubricId IN (SELECT Id FROM Rubric WHERE CloId = @CloId)", connection_1))
                        {
                            deleteAssessmentComponentCmd.Parameters.AddWithValue("@CloId", CloId);
                            deleteAssessmentComponentCmd.ExecuteNonQuery();
                        }

                        // Delete related records from the Rubric table
                        using (SqlCommand deleteRubricCmd = new SqlCommand("DELETE FROM Rubric WHERE CloId = @CloId", connection_1))
                        {
                            deleteRubricCmd.Parameters.AddWithValue("@CloId", CloId);
                            deleteRubricCmd.ExecuteNonQuery();
                        }

                        // Delete the record from the Clo table
                        using (SqlCommand deleteCloCmd = new SqlCommand("DELETE FROM Clo WHERE Id = @Id", connection_1))
                        {
                            deleteCloCmd.Parameters.AddWithValue("@Id", CloId);
                            deleteCloCmd.ExecuteNonQuery();
                        }
                    }

                    MessageBox.Show("Row Deleted Successfully !!!");
                    Grid_data();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            FrmHomeScreen H1 = new FrmHomeScreen();
            this.Hide();
            H1.Show();
        }
    }
}
