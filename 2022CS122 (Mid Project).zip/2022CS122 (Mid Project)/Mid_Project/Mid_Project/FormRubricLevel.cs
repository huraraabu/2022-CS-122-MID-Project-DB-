﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mid_Project
{
    public partial class FormRubricLevel : Form
    {
        public FormRubricLevel()
        {
            InitializeComponent();
            dataGridView1.SelectionChanged += dataGridView1_SelectionChanged;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }


        public void Grid_data()
        {
            var connection_1 = Configuration.getInstance().getConnection();
            SqlCommand cmd1 = new SqlCommand("SELECT * FROM RubricLevel", connection_1);
            SqlDataAdapter adopter_1 = new SqlDataAdapter(cmd1);
            DataTable data_table_1 = new DataTable();
            adopter_1.Fill(data_table_1);
            // Update the DataGridView
            dataGridView1.DataSource = data_table_1;
            connection_1.Close();
        }

        private void BtnReset_Click(object sender, EventArgs e)
        {
            cmBoxMeasurementLevel.Text = "";
            txtDetails.Text = "";
        }

        private void BtnRemove_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
                int Id = Convert.ToInt32(selectedRow.Cells["Id"].Value);
                var connection_1 = Configuration.getInstance().getConnection();
                SqlCommand sample_command = new SqlCommand("DELETE From RubricLevel WHERE Id = @Id", connection_1);
                sample_command.Parameters.AddWithValue("@Id", Id);
                connection_1.Open();
                sample_command.ExecuteNonQuery();
                connection_1.Close();
                MessageBox.Show("Row Deleted Successfully !!!");
                Grid_data();
            }
        }
        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
                int Id = Convert.ToInt32(selectedRow.Cells["Id"].Value);

                // Fetch data from the database based on the selected studentId
                var connection_1 = Configuration.getInstance().getConnection();
                SqlCommand sample_command = new SqlCommand("SELECT * FROM RubricLEvel WHERE Id = @Id", connection_1);
                sample_command.Parameters.AddWithValue("@Id", Id);
                connection_1.Open();
                SqlDataReader reader = sample_command.ExecuteReader();
                if (reader.Read())
                {
                    // Retrieve the values from the database
                    string details = reader["Details"].ToString();
                    int MeasurementLevel = Convert.ToInt32(reader["MeasurementLevel"]);

                    // Update the text boxes with the retrieved values
                    cmBoxMeasurementLevel.Text = MeasurementLevel.ToString();
                    txtDetails.Text = details;
                }

                reader.Close();
                connection_1.Close();
            }
        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                var connection_1 = Configuration.getInstance().getConnection();
                string Details = comboBox1.Text;
                SqlCommand RubricCmd = new SqlCommand("Select Id from Rubric WHERE Details = @Details", connection_1);
                RubricCmd.Parameters.AddWithValue("@Details", Details);
                connection_1.Open();
                int RubricId = Convert.ToInt32(RubricCmd.ExecuteScalar());

                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
                int Id = Convert.ToInt32(selectedRow.Cells["Id"].Value);

                //Retrieve Value From TextBoxes
                string details = txtDetails.Text;
                int MeasurementLevel = int.Parse(cmBoxMeasurementLevel.Text);
                //Updated the Values in the Table
                SqlCommand sample_command = new SqlCommand(@"UPDATE RubricLevel
                                            SET Details = @details,
                                                MeasurementLevel = @MeasurementLevel
                                                WHERE Id = @Id", connection_1);
                sample_command.Parameters.AddWithValue("@RubricId", RubricId);
                sample_command.Parameters.AddWithValue("@Details", details);
                sample_command.Parameters.AddWithValue("@MeasurementLevel", MeasurementLevel);
                sample_command.Parameters.AddWithValue("@Id", Id);
                sample_command.ExecuteNonQuery();
                connection_1.Close();
                MessageBox.Show("Row Updated Successfully !!!");
                Grid_data();
            }
        }
        public void ShowinComboBox()
        {
            var connection_1 = Configuration.getInstance().getConnection();
            connection_1.Open();
            SqlCommand sample_command = new SqlCommand(@"SELECT Details from Rubric", connection_1);

            SqlDataReader reader = null;

            reader = sample_command.ExecuteReader();

            // Clear existing items in the combo box
            comboBox1.Items.Clear();

            // Populate the combo box with registration numbers
            while (reader.Read())
            {
                string Details = reader["Details"].ToString();
                comboBox1.Items.Add(Details);
            }

            reader.Close();
            connection_1.Close();
        }

        private void FormRubricLevel_Load(object sender, EventArgs e)
        {
            Grid_data();
            ShowinComboBox();
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem == null)
            {
                MessageBox.Show("Please select a Rubric !!!");
                return;
            }
            using (SqlConnection connection_1 = Configuration.getInstance().getConnection())
            {
                connection_1.Open();

                // Retrieve the RubricId based on the selected Rubric name
                string selectedRubric = comboBox1.SelectedItem.ToString();
                SqlCommand cmd2 = new SqlCommand("SELECT Id FROM Rubric WHERE Details = @Details", connection_1);
                cmd2.Parameters.AddWithValue("@Details", selectedRubric);

                int RubricId = Convert.ToInt32(cmd2.ExecuteScalar());

                // Close the connection after retrieving the RubricId
                connection_1.Close();

                // Open a new connection for inserting the new entry into the RubricLevel table
                using (SqlConnection con1 = Configuration.getInstance().getConnection())
                {
                    con1.Open();

                    // Insert the new entry into the RubricLevel table
                    SqlCommand sample_command = new SqlCommand("INSERT into RubricLevel (RubricId, Details, MeasurementLevel) VALUES (@RubricId, @Details, @MeasurementLevel)", con1);
                    sample_command.Parameters.AddWithValue("@RubricId", RubricId);
                    sample_command.Parameters.AddWithValue("@Details", txtDetails.Text);
                    sample_command.Parameters.AddWithValue("@MeasurementLevel", cmBoxMeasurementLevel.Text);
                    sample_command.ExecuteNonQuery();
                    MessageBox.Show("Added Successfully !!!");
                    con1.Close();
                    Grid_data();
                }
            }
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            FrmHomeScreen H1 = new FrmHomeScreen();
            this.Hide();
            H1.Show();
        }
    }
}
