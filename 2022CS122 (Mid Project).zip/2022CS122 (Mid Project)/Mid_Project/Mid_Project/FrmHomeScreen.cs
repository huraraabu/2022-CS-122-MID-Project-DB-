﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mid_Project
{
    public partial class FrmHomeScreen : Form
    {
        public FrmHomeScreen()
        {
            InitializeComponent();
        }

        private void BtnStudent_Click(object sender, EventArgs e)
        {
            Form1 sample_form = new Form1();
            this.Hide();
            sample_form.Show();
        }

        private void BtnAttendance_Click(object sender, EventArgs e)
        {
            FrmStudentAttendance sample_form = new FrmStudentAttendance();
            this.Hide();
            sample_form.Show();
        }

        private void BtnAssessments_Click(object sender, EventArgs e)
        {
            FrmAssessment sample_form = new FrmAssessment();
            this.Hide();
            sample_form.Show();
        }

        private void BtnClo_Click(object sender, EventArgs e)
        {
            FrmCLO sample_form = new FrmCLO();
            this.Hide();
            sample_form.Show();
        }

        private void BtnComponents_Click(object sender, EventArgs e)
        {
            FrmAssessmentComponent sample_form = new FrmAssessmentComponent();
            this.Hide();
            sample_form.Show();
        }

        private void BtnRubric_Click(object sender, EventArgs e)
        {
            FrmRubric sample_form = new FrmRubric();
            this.Hide();
            sample_form.Show();
        }

        private void BtnRubricLevel_Click(object sender, EventArgs e)
        {
            FormRubricLevel sample_form = new FormRubricLevel();
            this.Hide();
            sample_form.Show();
        }

        private void BtnResult_Click(object sender, EventArgs e)
        {
            FrmStudentResult sample_form = new FrmStudentResult();
            this.Hide();
            sample_form.Show();
        }

        private void BtnSetting_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This Button is currently Unavailabe !!!");
        }
    }
}
