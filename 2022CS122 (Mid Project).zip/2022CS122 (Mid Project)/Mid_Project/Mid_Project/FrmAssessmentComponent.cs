﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Mid_Project
{
    public partial class FrmAssessmentComponent : Form
    {
        public FrmAssessmentComponent()
        {
            InitializeComponent();
            dataGridView1.SelectionChanged += dataGridView1_SelectionChanged;
        }

        private void Btn_Reset_Click(object sender, EventArgs e)
        {
            txtName.Text = "";
            txtTotalMarks.Text = "";
            dtPickerDateCreated.Value = DateTime.Now;
            dtPickerDateUpdated.Value = DateTime.Now;
        }

        private void Btn_Add_Click(object sender, EventArgs e)
        {
            if (comboBoxAssessment.Text != "" && comboBoxRubric.Text != "")
            {
                // Get the RubricId based on the Rubric name
                int rubricId;
                var connection_1 = Configuration.getInstance().getConnection();

                connection_1.Open();
                SqlCommand rubricCmd = new SqlCommand("SELECT Id FROM Rubric WHERE Details = @Details", connection_1);
                rubricCmd.Parameters.AddWithValue("@Details", comboBoxRubric.SelectedItem.ToString());
                rubricId = Convert.ToInt32(rubricCmd.ExecuteScalar());


                // Get the AssessmentId based on the Assessment name
                int assessmentId;


                SqlCommand assessmentCmd = new SqlCommand("SELECT Id FROM Assessment WHERE Title = @Title", connection_1);
                assessmentCmd.Parameters.AddWithValue("@Title", comboBoxAssessment.SelectedItem.ToString());
                assessmentId = Convert.ToInt32(assessmentCmd.ExecuteScalar());


                SqlCommand sample_command = new SqlCommand("INSERT INTO AssessmentComponent (Name, RubricId, TotalMarks, DateCreated, DateUpdated, AssessmentId) VALUES (@Name, @RubricId, @TotalMarks, @DateCreated, @DateUpdated, @AssessmentId)", connection_1);
                sample_command.Parameters.AddWithValue("@Name", txtName.Text);
                sample_command.Parameters.AddWithValue("@RubricId", rubricId);
                sample_command.Parameters.AddWithValue("@TotalMarks", int.Parse(txtTotalMarks.Text));
                sample_command.Parameters.AddWithValue("@DateCreated", dtPickerDateCreated.Value);
                sample_command.Parameters.AddWithValue("@DateUpdated", dtPickerDateUpdated.Value);
                sample_command.Parameters.AddWithValue("@AssessmentId", assessmentId);
                sample_command.ExecuteNonQuery();
                connection_1.Close();
                MessageBox.Show("Added Successfully !!!");
                ShowDataInGrid();
            }
            else
            {
                MessageBox.Show("Error : Please Select Rubric and Assessment !!!");
            }
        }

        private void FrmAssessmentComponent_Load(object sender, EventArgs e)
        {

            ShowDataInComboBox();
            ShowDataInGrid();
            dataGridView1.ForeColor = Color.Red;
        }
        public void ShowDataInComboBox()
        {
            var connection_1 = Configuration.getInstance().getConnection();
            SqlCommand sample_command = new SqlCommand(@"SELECT Details from Rubric", connection_1);

            SqlDataReader reader = null;

            reader = sample_command.ExecuteReader();

            // Clear existing items in the combo box
            comboBoxRubric.Items.Clear();

            // Populate the combo box with Details
            while (reader.Read())
            {
                string Details = reader["Details"].ToString();
                comboBoxRubric.Items.Add(Details);
            }
            reader.Close();

            SqlCommand cmd1 = new SqlCommand(@"SELECT Title from Assessment", connection_1);

            SqlDataReader reader1 = null;

            reader1 = cmd1.ExecuteReader();

            // Clear existing items in the combo box
            comboBoxAssessment.Items.Clear();

            // Populate the combo box with TItle
            while (reader1.Read())
            {
                string Title = reader1["Title"].ToString();
                comboBoxAssessment.Items.Add(Title);
            }

            reader1.Close();
            connection_1.Close();
        }
        public void ShowDataInGrid()
        {
            var connection_1 = Configuration.getInstance().getConnection();
            SqlCommand cmd1 = new SqlCommand("SELECT * FROM AssessmentComponent", connection_1);
            SqlDataAdapter adopter_1 = new SqlDataAdapter(cmd1);
            DataTable data_table_1 = new DataTable();
            adopter_1.Fill(data_table_1);
            // Update the DataGridView
            dataGridView1.DataSource = data_table_1;
            connection_1.Close();
        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                var connection_1 = Configuration.getInstance().getConnection();
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
                int Id = Convert.ToInt32(selectedRow.Cells["Id"].Value);

                //Retrieve Value From TextBoxes
                string Name = txtName.Text;
                int TotalMarks = int.Parse(txtTotalMarks.Text);
                DateTime dateCreated = dtPickerDateCreated.Value;
                DateTime dateUpdated = dtPickerDateUpdated.Value;
                //Updated the Values in the Table
                SqlCommand sample_command = new SqlCommand(@"UPDATE AssessmentComponent
                                            SET Name = @Name,
                                                TotalMarks = @TotalMarks,
                                                DateCreated = @dateCreated,
                                                DateUpdated = @dateUpdated
                                                WHERE Id = @Id", connection_1);
                sample_command.Parameters.AddWithValue("@Name", Name);
                sample_command.Parameters.AddWithValue("@TotalMarks", TotalMarks);
                sample_command.Parameters.AddWithValue("@DateCreated", dateCreated);
                sample_command.Parameters.AddWithValue("@DateUpdated", dateUpdated);
                sample_command.Parameters.AddWithValue("@Id", Id);
                connection_1.Open();
                sample_command.ExecuteNonQuery();
                connection_1.Close();
                MessageBox.Show("Row Updated Successfully !!!");
                ShowDataInGrid();
            }
        }
        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
                int Id = Convert.ToInt32(selectedRow.Cells["Id"].Value);

                // Fetch data from the database based on the selected studentId
                var connection_1 = Configuration.getInstance().getConnection();
                SqlCommand sample_command = new SqlCommand("SELECT * FROM AssessmentComponent WHERE Id = @Id", connection_1);
                sample_command.Parameters.AddWithValue("@Id", Id);
                connection_1.Open();
                SqlDataReader reader = sample_command.ExecuteReader();

                if (reader.Read())
                {
                    // Retrieve the values from the database
                    string Name = reader["Name"].ToString();
                    int TotalMarks = Convert.ToInt32(reader["TotalMarks"]);
                    DateTime dateCreated = Convert.ToDateTime(reader["DateCreated"]);
                    DateTime dateUpdtaed = Convert.ToDateTime(reader["DateUpdated"]);
                    // Update the text boxes with the retrieved values
                    txtName.Text = Name;
                    txtTotalMarks.Text = TotalMarks.ToString();
                    dtPickerDateCreated.Value = dateCreated;
                    dtPickerDateUpdated.Value = dateUpdtaed;
                }

                reader.Close();
                connection_1.Close();
            }
        }

        private void BtnRemove_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
                int Id = Convert.ToInt32(selectedRow.Cells["Id"].Value);
                var connection_1 = Configuration.getInstance().getConnection();
                SqlCommand sample_command = new SqlCommand("DELETE From AssessmentComponent WHERE Id = @Id", connection_1);
                sample_command.Parameters.AddWithValue("@Id", Id);
                connection_1.Open();
                sample_command.ExecuteNonQuery();
                connection_1.Close();
                MessageBox.Show("Row Deleted Successfully !!!");
                ShowDataInGrid();
            }
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            FrmHomeScreen H1 = new FrmHomeScreen();
            this.Hide();
            H1.Show();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void lblItemName_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void lblType_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
