﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
namespace Mid_Project
{
    public partial class AddStudent : UserControl
    {
        public AddStudent()
        {
            InitializeComponent();
            dataGridView1.SelectionChanged += dataGridView1_SelectionChanged;
        }

        private void Btn_Add_Click(object sender, EventArgs e)
        {
            var connection_1 = Configuration.getInstance().getConnection();
            SqlCommand sample_command = new SqlCommand("Insert into Student values (@FirstName, @LastName, @Contact, @Email, @RegistrationNumber, @Status)", connection_1);
            sample_command.Parameters.AddWithValue("@FirstName", txtFirstName.Text);
            sample_command.Parameters.AddWithValue("@LastName", txtLastName.Text);
            sample_command.Parameters.AddWithValue("@Contact", txtContact.Text);
            sample_command.Parameters.AddWithValue("@Email", txtEmail.Text);
            sample_command.Parameters.AddWithValue("@RegistrationNumber", txtRegesteration.Text);
            sample_command.Parameters.AddWithValue("@Status", int.Parse(comboBox1.Text));

            sample_command.ExecuteNonQuery();
            MessageBox.Show("Successfully saved");
            sample_command = new SqlCommand("Select * from Student", connection_1);
            SqlDataAdapter adopter_1 = new SqlDataAdapter(sample_command);
            DataTable data_table_1 = new DataTable();
            adopter_1.Fill(data_table_1);
            dataGridView1.DataSource = data_table_1;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Btn_Reset_Click(object sender, EventArgs e)
        {
            txtFirstName.Text = "";
            txtLastName.Text = "";
            txtContact.Text = "";
            txtRegesteration.Text = "";
            txtEmail.Text = "";
            comboBox1.Text = "";
        }

        private void lblcheck_Click(object sender, EventArgs e)
        {

        }

        private void AddStudent_Load(object sender, EventArgs e)
        {
            var connection_1 = Configuration.getInstance().getConnection();
            SqlCommand sample_command = new SqlCommand("Select * from Student", connection_1);
            SqlDataAdapter adopter_1 = new SqlDataAdapter(sample_command);
            DataTable data_table_1 = new DataTable();
            adopter_1.Fill(data_table_1);
            dataGridView1.DataSource = data_table_1;
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
        }
        //Function to show the selected row in the text boxes
        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
                int studentId = Convert.ToInt32(selectedRow.Cells["Id"].Value);

                // Fetch data from the database based on the selected studentId
                var connection_1 = Configuration.getInstance().getConnection();
                SqlCommand sample_command = new SqlCommand("SELECT * FROM Student WHERE Id = @Id", connection_1);
                sample_command.Parameters.AddWithValue("@Id", studentId);
                SqlDataReader reader = sample_command.ExecuteReader();

                if (reader.Read())
                {
                    // Retrieve the values from the database
                    string firstName = reader["FirstName"].ToString();
                    string lastName = reader["LastName"].ToString();
                    string contact = reader["Contact"].ToString();
                    string email = reader["Email"].ToString();
                    string registrationNumber = reader["RegistrationNumber"].ToString();
                    int status = Convert.ToInt32(reader["Status"]);

                    // Update the text boxes with the retrieved values
                    txtFirstName.Text = firstName;
                    txtLastName.Text = lastName;
                    txtContact.Text = contact;
                    txtEmail.Text = email;
                    txtRegesteration.Text = registrationNumber;
                    comboBox1.Text = status.ToString();
                }

                reader.Close();
            }
        }

        private void Btn_Save_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

                // Retrieve the updated values from the textboxes and ComboBox
                string firstName = txtFirstName.Text;
                string lastName = txtLastName.Text;
                string contact = txtContact.Text;
                string email = txtEmail.Text;
                string registrationNumber = txtRegesteration.Text;
                int status = int.Parse(comboBox1.Text);

                // Update the selected row in the database
                var connection_1 = Configuration.getInstance().getConnection();
                SqlCommand sample_command = new SqlCommand(@"UPDATE Student 
                                          SET FirstName = @FirstName, 
                                              LastName = @LastName, 
                                              Contact = @Contact, 
                                              Email = @Email, 
                                              RegistrationNumber = @RegistrationNumber, 
                                              Status = @Status 
                                          WHERE Id = @Id", connection_1);

                sample_command.Parameters.AddWithValue("@FirstName", firstName);
                sample_command.Parameters.AddWithValue("@LastName", lastName);
                sample_command.Parameters.AddWithValue("@Contact", contact);
                sample_command.Parameters.AddWithValue("@Email", email);
                sample_command.Parameters.AddWithValue("@RegistrationNumber", registrationNumber);
                sample_command.Parameters.AddWithValue("@Status", status);
                sample_command.Parameters.AddWithValue("@Id", Convert.ToInt32(selectedRow.Cells["Id"].Value));

                sample_command.ExecuteNonQuery();
                MessageBox.Show("Row updated successfully.");

                // Refresh DataGridView
                SqlCommand refreshCmd = new SqlCommand("SELECT * FROM Student", connection_1);
                SqlDataAdapter adopter_1 = new SqlDataAdapter(refreshCmd);
                DataTable data_table_1 = new DataTable();
                adopter_1.Fill(data_table_1);
                dataGridView1.DataSource = data_table_1;
            }
        }

        //Function to Remove the student from the database
        private void Btn_Delete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
                int studentId = Convert.ToInt32(selectedRow.Cells["Id"].Value); 

                // Remove the selected row from the database
                var connection_1 = Configuration.getInstance().getConnection();
                SqlCommand sample_command = new SqlCommand("DELETE FROM Student WHERE Id = @Id", connection_1);
                sample_command.Parameters.AddWithValue("@Id", studentId);

                // Execute the command
                sample_command.ExecuteNonQuery();
                MessageBox.Show("Row deleted successfully.");

                // Refresh DataGridView
                SqlCommand refreshCmd = new SqlCommand("SELECT * FROM Student", connection_1);
                SqlDataAdapter adopter_1 = new SqlDataAdapter(refreshCmd);
                DataTable data_table_1 = new DataTable();
                adopter_1.Fill(data_table_1);
                dataGridView1.DataSource = data_table_1;
            }
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            FrmHomeScreen H1 = new FrmHomeScreen();
            Form1 sample_form = new Form1();
            this.Hide();
            sample_form.Close();
            H1.Show();
        }
    }
}
